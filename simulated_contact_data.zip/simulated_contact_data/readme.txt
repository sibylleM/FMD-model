Simulated example data

contacts.csv (time, from, to, weight) = links between individual ID’s with associated time and “weight”, I.e. the duration of the contact. Note that the weights are not yet the way I intend them to be, but are just drawn from a log-normal distribution; The links could have further attributes e.g. location of the contact (hospital, supermarket, etc);

Individuals.csv (id): These represent individual ID’s  / nodes in the network; this could contain more information e.g. something like age group, gender,…;